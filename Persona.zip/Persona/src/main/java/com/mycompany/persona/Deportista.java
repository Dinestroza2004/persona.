/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.persona;

/**
 *
 * @author Pc
 */
// Subclase Deportista
public class Deportista extends Persona {
    private String deporte;

    // Constructor
    public Deportista(String nombre, int edad, String deporte) {
        super(nombre, edad);
        this.deporte = deporte;
    }

    // Getter y setter
    public String getDeporte() {
        return deporte;
    }

    public void setDeporte(String deporte) {
        this.deporte = deporte;
    }

    // Implementación del método abstracto
    @Override
    public void mostrarInformacion() {
        System.out.println("Deportista: " + getNombre() + ", Edad: " + getEdad() + ", Deporte: " + deporte);
    }
}
